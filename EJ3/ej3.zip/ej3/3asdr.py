tokens = ["dos", "cuatro", "tres", "uno", "$"]
pos = 0

def match(t):
    global pos
    if pos < len(tokens) and tokens[pos] == t:
        pos += 1
    else:
        raise Exception("Error de sintaxis")

def S():
    if tokens[pos] in {"dos", "cuatro", "tres", "uno"}:
        A()
        B()
        C()
        Sp()
    else:
        raise Exception("Error en S")

def Sp():
    if tokens[pos] == "uno":
        match("uno")
        Sp()
    else:
        pass

def A():
    if tokens[pos] == "dos":
        match("dos")
        B()
        C()
    else:
        pass

def B():
    if tokens[pos] in {"cuatro", "tres"}:
        C()
        match("tres")
    else:
        pass

def C():
    if tokens[pos] == "cuatro":
        match("cuatro")
        B()
    else:
        pass

try:
    S()
    if tokens[pos] == "$":
        print("Cadena válida")
    else:
        print("Cadena inválida")
except:
    print("Cadena inválida")
