# Gramatica sin recursividad
gramatica = {
    "S": [["A", "B", "C", "S'"]],
    "S'": [["uno", "S'"], ["ε"]],
    "A": [["dos", "B", "C"], ["ε"]],
    "B": [["C", "tres"], ["ε"]],
    "C": [["cuatro", "B"], ["ε"]]
}

# Primeros
def calcularPrimeros(gramatica):
    primeros = {nt: set() for nt in gramatica}

    cambio = True
    while cambio:
        cambio = False

        for A in gramatica:
            for produccion in gramatica[A]:

                for simbolo in produccion:
                    if simbolo not in gramatica:
                        if simbolo not in primeros[A]:
                            primeros[A].add(simbolo)
                            cambio = True
                        break
                    else:
                        antes = len(primeros[A])
                        primeros[A].update(primeros[simbolo] - {"ε"})

                        if "ε" not in primeros[simbolo]:
                            if len(primeros[A]) > antes:
                                cambio = True
                            break
                else:
                    if "ε" not in primeros[A]:
                        primeros[A].add("ε")
                        cambio = True

    return primeros

# Siguientes
def calcularSiguientes(gramatica, primeros, inicio):
    siguientes = {nt: set() for nt in gramatica}
    siguientes[inicio].add("$")

    cambio = True

    while cambio:
        cambio = False

        for A in gramatica:
            for produccion in gramatica[A]:

                for i in range(len(produccion)):
                    B = produccion[i]

                    if B in gramatica:
                        beta = produccion[i+1:]

                        first_beta = set()
                        contiene_epsilon = True

                        for simbolo in beta:
                            if simbolo in gramatica:
                                first_beta.update(primeros[simbolo] - {"ε"})
                                if "ε" not in primeros[simbolo]:
                                    contiene_epsilon = False
                                    break
                            else:
                                first_beta.add(simbolo)
                                contiene_epsilon = False
                                break

                        if contiene_epsilon:
                            first_beta.add("ε")

                        antes = len(siguientes[B])

                        siguientes[B].update(first_beta - {"ε"})

                        if "ε" in first_beta:
                            siguientes[B].update(siguientes[A])

                        if len(siguientes[B]) > antes:
                            cambio = True

    return siguientes

# Primeros de cadena
def primerosCadena(cadena, primeros):
    resultado = set()

    for simbolo in cadena:
        if simbolo in primeros:
            resultado.update(primeros[simbolo] - {"ε"})
            if "ε" not in primeros[simbolo]:
                return resultado
        else:
            resultado.add(simbolo)
            return resultado

    resultado.add("ε")
    return resultado


# Prediccion
def calcularPrediccion(gramatica, primeros, siguientes):
    prediccion = {}

    for A in gramatica:
        prediccion[A] = []

        for produccion in gramatica[A]:
            first_alpha = primerosCadena(produccion, primeros)

            conjunto = set(first_alpha - {"ε"})

            if "ε" in first_alpha:
                conjunto.update(siguientes[A])

            prediccion[A].append((produccion, conjunto))

    return prediccion


# Verificacion del LL1
def esLL1(prediccion):
    for A in prediccion:
        conjuntos = [p[1] for p in prediccion[A]]

        for i in range(len(conjuntos)):
            for j in range(i+1, len(conjuntos)):
                if conjuntos[i].intersection(conjuntos[j]):
                    return False
    return True

def imprimirResultados(primeros, siguientes, prediccion):
    print("----- Primeros -----")
    for nt in primeros:
        print(nt, ":", primeros[nt])

    print("\n----- Siguientes -----")
    for nt in siguientes:
        print(nt, ":", siguientes[nt])

    print("\n----- Prediccion -----")
    for nt in prediccion:
        for prod, conj in prediccion[nt]:
            print(f"{nt} → {' '.join(prod)} : {conj}")

primeros = calcularPrimeros(gramatica)
siguientes = calcularSiguientes(gramatica, primeros, "S")
prediccion = calcularPrediccion(gramatica, primeros, siguientes)

imprimirResultados(primeros, siguientes, prediccion)

print("\n-----   -----")
if esLL1(prediccion):
    print("La gramática ES LL1")
else:
    print("La gramática NO es LL1")
