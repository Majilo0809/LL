tokens = ["dos", "cuatro", "cinco", "tres", "$"]
pos = 0

def match(t):
    global pos
    if pos < len(tokens) and tokens[pos] == t:
        pos += 1
    else:
        raise Exception("Error de sintaxis")

def S():
    if tokens[pos] in {"dos", "cuatro", "seis"}:
        A(); B(); C()
    elif tokens[pos] == "uno":
        D(); E()
    else:
        raise Exception("Error en S")

def A():
    if tokens[pos] == "dos":
        match("dos")
        B()
        match("tres")
    else:
        pass

def B():
    Bp()

def Bp():
    if tokens[pos] == "cuatro":
        match("cuatro")
        C()
        match("cinco")
        Bp()
    else:
        pass

def C():
    if tokens[pos] == "seis":
        match("seis")
        A()
        B()
    else:
        pass

def D():
    if tokens[pos] == "uno":
        match("uno")
        A()
        E()
    else:
        B()

def E():
    if tokens[pos] == "tres":
        match("tres")
    else:
        raise Exception("Error en E")

try:
    S()
    if tokens[pos] == "$":
        print("Cadena válida")
    else:
        print("Cadena inválida")
except:
    print("Cadena inválida")
