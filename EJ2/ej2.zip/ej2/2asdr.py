	tokens = ["dos", "siete", "cinco", "seis", "uno", "$"]
pos = 0

def match(t):
    global pos
    if pos < len(tokens) and tokens[pos] == t:
        pos += 1
    else:
        raise Exception("Error de sintaxis")

def S():
    if tokens[pos] == "dos":
        match("dos")
        C()
    elif tokens[pos] in {"uno", "cuatro", "siete", "tres", "cinco"}:
        B()
        match("uno")
    else:
        pass

def A():
    if tokens[pos] in {"dos", "uno", "cuatro", "siete", "tres"}:
        S()
        match("tres")
        B()
        C()
    elif tokens[pos] == "cuatro":
        match("cuatro")
    else:
        pass

def B():
    if tokens[pos] in {"dos", "uno", "cuatro", "siete", "tres", "cinco"}:
        A()
        match("cinco")
        C()
        match("seis")
    else:
        pass

def C():
    if tokens[pos] == "siete":
        match("siete")
        B()
    else:
        pass

try:
    S()
    if tokens[pos] == "$":
        print("Cadena válida")
    else:
        print("Cadena inválida")
except:
    print("Cadena inválida")
